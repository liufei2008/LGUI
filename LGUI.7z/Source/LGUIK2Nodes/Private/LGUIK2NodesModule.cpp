﻿// Copyright 2019-2022 LexLiu. All Rights Reserved.

#include "LGUIK2NodesModule.h"

#define LOCTEXT_NAMESPACE "FLGUIK2NodesModule"
DEFINE_LOG_CATEGORY(LGUIK2Nodes);

void FLGUIK2NodesModule::StartupModule()
{

}

void FLGUIK2NodesModule::ShutdownModule()
{
	
}
IMPLEMENT_MODULE(FLGUIK2NodesModule, LGUIK2Nodes)

#undef LOCTEXT_NAMESPACE