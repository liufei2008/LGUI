﻿// Copyright 2019-2022 LexLiu. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"


class FLGUIContentBrowserExtensions
{
public:
	static void InstallHooks();
	static void RemoveHooks();
};