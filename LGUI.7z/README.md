<p align="center"><img width="100" src="./Resources/Icon128.png" alt="LGUI logo"></a></p>

<h2 align="center">LGUI (Lex GUI) - 3D UI System for UE4</h2>
<p align="center">
Powerful Component based 3D UI System, Event Framework, Prefab Workflow, Tween Animation.
</p>



## License

[MIT](https://opensource.org/licenses/MIT)

Copyright (c) 2019-present, Lex Liu

## Contact
QQ: 537144721